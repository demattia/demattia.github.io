#ifndef NEURON_HH
#define NEURON_HH

#include <cmath>
#include <vector>
// For random number generation
#include <cstdlib>
#include <ctime>
#include <iostream>

#include "ScalarProd.h"

class Neuron {
 public:
  Neuron( unsigned int SYNAPSE_NUM, double k = 1. ) {
    k_ = k;
    for ( unsigned int i = 0; i < SYNAPSE_NUM; ++i ) {

      // Put a random number [0,1] in the vector
      // ---------------------------------------
      // The rand() function returns an integer between 0 and RAND_MAX
      // To take a double [0,1] divide
      double random_double = double( rand() )/(double( RAND_MAX ));

#ifdef DEBUG
      std::cout << "random_double[0,1] = " << random_double << std::endl;
#endif

      weights_.push_back( random_double );

#ifdef DEBUG
      std::cout << "starting weight = " << random_double << std::endl; 
#endif

    }
  }
  // transfer function
  double Transfer (std::vector<double> & V_P);

  // return the vector of weights
  std::vector<double> & Weights() {
    return weights_;
  }
 private:
  double k_;
  std::vector<double> weights_;
};

#endif // NEURON_HH
