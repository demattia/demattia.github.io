#ifndef NN_H
#define NN_H

///////////////////////////////////////////////////////////////
//
// Neural Network class
// Author M. De Mattia - 6/8/2007
//
// Represents a MLP network which learns through the
// back-propagation algorithm.
// The number of neurons can be selected with the constructor.
//
// Must put the neurons in comunication
// Must have the structure of the network (different layers
// each with it's neurons).
// 
//
///////////////////////////////////////////////////////////////

#include <vector>
#include <memory>

#include "Neuron.cc"

class NN {
 public:
  /** Constructor building the network and initializing the connections with random values. \br
   * Used for training.
   */
  NN( std::vector<int> & NEURONS_PER_LAYER );

  /** Constructor from file. Must pass a file defining the structure of the network and the weights
   * of all the connections. \br
   * The name of the file is passed as a char*.
   */
  NN( char* fileName );

  ~NN() {}
  std::vector<double> Answer( std::vector<double> & V_IN );
  /// Learn method, returns a pair<maxEra, Error>
  std::pair<unsigned int, double> Learn( vector<vector<double> > & V_IN, vector<vector<double> > & V_CONTROL, double ETA = 0.25, double BETA = 0.25, double MIN_ERROR = 0.01, unsigned int MAX_ERA = 1000, TH1F * ERRORHISTO = 0 );

 private:
  void FeedForward_( std::vector<double> & V_OUT, unsigned int LAYER );
  void BackPropagation_(std::vector<double> & V_DELTA, unsigned int LAYER);

  // Evalute f' = Y(1-Y)
  double FPrime_( double Y ) {
    return Y*(1.-Y);
  }

  unsigned int layers_;
  double eta_;
  double beta_;
  double min_error_;
  unsigned int max_era_;

  std::vector<double> v_in_;
  std::vector<std::vector<Neuron> > Layers_;
  std::vector<std::vector<double> > output_;
  std::vector<std::vector<std::vector<double> > > v_momentum_;
};

#endif // NN_H
