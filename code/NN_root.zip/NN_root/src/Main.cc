//#define DEBUG

#include <iostream>
#include <string>
#include <sstream>

#include "TFile.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TCanvas.h"
#include "TLegend.h"

#include "NN.cc"

int main () {

  using namespace std;

  // Maximum number of era
  int maxEra = 1000;

  // The number will be used 
  int maxMomentum = 20;
  int minLearnRate = 40;
  int maxLearnRate = 60;

  // Total number of times to iterate over the same cuts
  // Needed to evaluate the mean number of era
  int maxIterationNum = 1;

  // Create a vector<vector<unsigned int> > to store the mean era numbers
  // Creates the vector with [10,10] elements and initializes them to zero
  vector<vector<unsigned int> > eraNum(maxLearnRate,maxMomentum);

  // Error histogram
  TFile rootFile( "Error.root", "RECREATE" );

  TH2F meanEraHisto( "meanEraNum", "mean number of era for training", maxLearnRate, 0, maxLearnRate, maxMomentum, 0, maxMomentum );

  // Loop to iterate N times on the same parameters and evaluate the mean number of eras
  for( int iteration=0; iteration<maxIterationNum; ++iteration ) {

    // Loop on the momenta
    for ( int momentumId = 0; momentumId < maxMomentum; ++momentumId ) {

      double momentum = momentumId*0.01;

      stringstream momentumNum;
      momentumNum << momentum;
      string errorCanvasTitle("momentum ");
      string errorCanvasName("momentum_");
      errorCanvasTitle += momentumNum.str();
      errorCanvasName += momentumNum.str();
      TCanvas errorCanvas( errorCanvasName.c_str(), errorCanvasTitle.c_str(), 1000, 600 );
      TLegend * errorLegend = new TLegend(0.7,0.7,1.,1.);

      // Loop to evaluate different learn rates and momenta
      for ( int learnRateId = minLearnRate; learnRateId < maxLearnRate; ++learnRateId ) {

        double learnRate = (learnRateId+1)*0.1;

        cout << "iteration = " << iteration << ", learnRate = " << learnRate << ", momentum = " << momentum << endl;

        // Create the histogram, let root control the memory deallocation
        stringstream learnRateNum;
        learnRateNum << learnRate;
        string errorHistoTitle("learn rate ");
        string errorHistoName("learn_rate_");
        errorHistoTitle += learnRateNum.str();
        errorHistoName += learnRateNum.str();

        errorCanvas.cd();
        TH1F * errorHisto = new TH1F( errorHistoName.c_str(), errorHistoTitle.c_str(), maxEra, 0, maxEra );
        errorHisto->SetDirectory(0);
        errorHisto->SetLineColor(learnRateId);

        // Creates a vector with 2 entries initialized with the value 1
        //  vector<int> Layers( 2, 1 );

        vector<int> Layers;
        Layers.push_back(2);
        Layers.push_back(3);
        //  Layers.push_back(6);
        //  Layers.push_back(32);
        Layers.push_back(1);

        NN test( Layers );

        // Test the NN with a vector(0.1,0.9)
	// Not exactly 0 and 1 because these are asymptotic points for
	// the sigmoid function and it would be long to reduce the errors
	// near them.
        vector<double> v1(2,0.1);
        vector<double> v2;
        v2.push_back(0.1);
        v2.push_back(0.9);
        vector<double> v3(2,0.9);
        vector<double> v4;
        v4.push_back(0.9);
        v4.push_back(0.1);

//       // Get the answer from NN for this input
//       vector<double> v_out1( test.Answer(v1) );
//       std::cout << "this is a test, output = " << v_out1[0] << std::endl;
//       vector<double> v_out2( test.Answer(v2) );
//       std::cout << "this is a test, output = " << v_out2[0] << std::endl;
//       vector<double> v_out3( test.Answer(v3) );
//       std::cout << "this is a test, output = " << v_out3[0] << std::endl;
//       vector<double> v_out4( test.Answer(v4) );
//       std::cout << "this is a test, output = " << v_out4[0] << std::endl;

        // Learn from the control vector

        vector<vector<double> > v_v;
        v_v.push_back(vector<double>( 2, 0.1 ));
        vector<double> temp_v;
        temp_v.push_back(0.1);
        temp_v.push_back(0.9);
        v_v.push_back(temp_v);
        v_v.push_back(vector<double>( 2, 0.9 ));
        vector<double> temp_v2;
        temp_v2.push_back(0.9);
        temp_v2.push_back(0.1);
        v_v.push_back(temp_v2);

        vector<vector<double> > v_v_control;
        v_v_control.push_back(vector<double>( 1, 0.1 ));
        v_v_control.push_back(vector<double>( 1, 0.9 ));
        v_v_control.push_back(vector<double>( 1, 0.1 ));
        v_v_control.push_back(vector<double>( 1, 0.9 ));

        // Finished learning, draw the histogram
        if ( iteration == 0 ) {
          pair<unsigned int, double> learnResult = test.Learn(v_v, v_v_control, learnRate, momentum, 0.001, maxEra, errorHisto);
          if ( learnRateId == 0 ) errorHisto->Draw("same");
          else errorHisto->Draw("same");
          errorLegend->AddEntry( errorHisto, errorHisto->GetName(), "l" );
          eraNum[learnRateId][momentumId] += learnResult.first;
        }
        else {
          pair<unsigned int, double> learnResult = test.Learn(v_v, v_v_control, learnRate, momentum, 0.001, maxEra);
          eraNum[learnRateId][momentumId] += learnResult.first;
        }
//       vector<double> v_out1_2( test.Answer(v1) );
//       std::cout << "this is a test, output = " << v_out1_2[0] << std::endl;
//       vector<double> v_out2_2( test.Answer(v2) );
//       std::cout << "this is a test, output = " << v_out2_2[0] << std::endl;
//       vector<double> v_out3_2( test.Answer(v3) );
//       std::cout << "this is a test, output = " << v_out3_2[0] << std::endl;
//       vector<double> v_out4_2( test.Answer(v4) );
//       std::cout << "this is a test, output = " << v_out4_2[0] << std::endl;
      }

      if ( iteration == 0 ) {
        errorLegend->Draw("same");
        errorCanvas.Write();
      }
    }
  }

  // Fill the histogram with the mean values
  vector<vector<unsigned int> >::const_iterator vecVec_it = eraNum.begin();
  int i = 1;
  for( ; vecVec_it != eraNum.end(); ++vecVec_it, ++i ) {
    int j = 1;
    vector<unsigned int>::const_iterator vec_it = vecVec_it->begin();
    for( ; vec_it != vecVec_it->end(); ++vec_it, ++j ) {
      meanEraHisto.SetBinContent( i, j, double(*vec_it)/double(maxIterationNum) );
      //      cout << "a["<<i<<","<<j<<"]= " << *vec_it << endl;
    }
  }

  rootFile.Write();

  return 0;
};
