#ifndef NN_CC
#define NN_CC

#include "NN.h"

using namespace std;

NN::NN( vector<int> & NEURONS_PER_LAYER ) {

  max_era_ = 0;

  // Initialize the random number generator used to assign random starting weights
  // to the synapses in the Neuron
  srand(time(0));

  // The input layer is not a true layer, thus there are (layers_ - 1) layers.
  layers_ = NEURONS_PER_LAYER.size() - 1;

  // Initialize the momentum vector
  for ( unsigned int i=0; i<layers_; ++i ) {
    vector<vector<double> > a;
    v_momentum_.push_back( a );
    for ( int j=0; j<NEURONS_PER_LAYER[i+1]; ++j ) {
      v_momentum_[i].push_back( vector<double>( NEURONS_PER_LAYER[i], 0. ) );
#ifdef DEBUG
      for ( int k=0; k<NEURONS_PER_LAYER[i]; ++k ) {
        cout << "v_momentum_[i][j][k] = " << v_momentum_[i][j][k] << endl;
      }
#endif
    }
  }

#ifdef DEBUG
  std::cout << "number of layers = " << layers_ << std::endl;
#endif

  // For now use a vector<<vector<Neuron> >, but consider
  // the possibility to use a multiarray or something which
  // helps to reduce the access time (to access a vector entry with
  // the actual structure 2 random access and a ptr dereference are done).

  Layers_.reserve(layers_);

  // The first number in the NEURONS_PER_LAYER vector is the number of inputs
  // Start to construct layers of neurons from the second number
  // Since the layers_ number is size - 1, loop up to layers_ + 1.
  // Using layers_ = size - 1 eases things later.
  for( unsigned int layer = 1; layer < layers_ + 1; ++layer ) {
    // This creates the vector and initializes it with the values

    unsigned int num_neurons = NEURONS_PER_LAYER[ layer ];
    unsigned int num_synapses = NEURONS_PER_LAYER[ layer -1 ];

    // Create a vector of neurons and initialize them

    vector<Neuron> temp_vec_neuron;

    for ( unsigned int n = 0; n < num_neurons; ++n ) {
      temp_vec_neuron.push_back( Neuron( num_synapses ) );
    }

#ifdef DEBUG
    std::cout << "num_neurons = " << num_neurons << std::endl;
    std::cout << "num_synapses = " << num_synapses << std::endl;
    std::cout << "vecsize = " << temp_vec_neuron.size() << std::endl;
#endif

    Layers_.push_back( temp_vec_neuron );
  }

  // Each neuron must have a vector of weights with size = number of neurons of the preceding layer (for the
  // input layer it equals the number of inputs).
}

NN::NN( char* fileName ) {
}

vector<double> NN::Answer( vector<double> & V_IN ) {

  // First empty the output vector<vector<double> >
//   for (vector<vector<double> >::iterator cl_it = output_.begin(); cl_it != output_.end(); ++cl_it) {
//     cl_it->clear();
//   }
  output_.clear();

//   v_in_.clear();
  v_in_ = V_IN;

  // Feed forward method
  // Passes the input vector to the first hidden layer.
  // From this iteratively retrieves the output vector
  // and passes it to the next layer.
  // When the ouput layer is reached, the output vector is returned.

  // Use recursivity for this method


#ifdef DEBUG
  std::cout << "received the vector: (" << v_in_[0] << ", " << v_in_[1] << ")" << std::endl;
#endif

  // For each layer, loop on all the neurons and pass the input vector
  // to each of them.
  FeedForward_( v_in_, 0 );

  return output_.back();
};

void NN::FeedForward_( vector<double> & V_OUT, unsigned int LAYER ) {

#ifdef DEBUG
  int count = 0;
  std::cout << "V_OUT.size() = " << V_OUT.size() << std::endl;
  for (vector<double>::iterator ti = V_OUT.begin(); ti!= V_OUT.end(); ++ti) {
    std::cout << "V_OUT["<<count<<"] = " << *ti << std::endl;
    ++count;
  }
#endif

  // Output vector to be passed recursively to this method
  vector<double> temp_output;
  vector<Neuron> & v_layer = Layers_[LAYER];

#ifdef DEBUG
  std::cout << "Number of neurons in this layer = " << v_layer.size() << std::endl;
#endif

  // For now use an iterator (in place of a const_iterator)
  for ( vector<Neuron>::iterator N_it = v_layer.begin(); N_it != v_layer.end(); ++N_it ) {
    temp_output.push_back( N_it->Transfer( V_OUT ) );
  }

  // Save the temp_output in the overall vector<vector<double> > (needed for Learn)
  // Cannot use pointers and modify the vector<vector<double> > since the pointer
  // would become invalid.
  output_.push_back(temp_output);

  // Check with (layers_ - 1) because it is incremented at the end (when calling the next FeedForward)
  if ( LAYER < layers_ - 1 ) {
    FeedForward_( temp_output, LAYER + 1 );
  }
  else {
#ifdef DEBUG
    std::cout << "output.size() = " << output_.back().size() << std::endl;
    std::cout << "temp_output.size() = " << temp_output.size() << std::endl;
#endif
  }
};

pair<unsigned int, double> NN::Learn( vector<vector<double> > & V_IN, vector<vector<double> > & V_CONTROL, double ETA, double BETA, double MIN_ERROR, unsigned int MAX_ERA, TH1F * ERRORHISTO ) {

  eta_ = ETA;
  beta_ = BETA;
  min_error_ = MIN_ERROR;

  double Error = 0.;

  for ( ; max_era_ < MAX_ERA; ++max_era_ ) {

  Error = 0.;

    vector<vector<double> >::iterator Control = V_CONTROL.begin();
    vector<vector<double> >::iterator Presentation = V_IN.begin();
    for ( ; Presentation != V_IN.end(); ++Presentation ) {

      vector<double> & v_control(*Control);

      vector<double> v_out( Answer(*Presentation) );

      if ( v_out.size() == v_control.size() ) {

	double err = 0.;

	// Evaluate the delta, which will be passed to the BackPropagation

	vector<double> v_delta;
	vector<double>::iterator out_it = v_out.begin();
	vector<double>::iterator control_it = v_control.begin();
	for ( ; out_it != v_out.end(); ++out_it ) {

	  double Delta = (*out_it - *control_it );
	  v_delta.push_back( Delta*FPrime_(*out_it) );

	  err += Delta*Delta;

	  ++control_it;
	}

	// Evaluate the "standard deviation"
	Error += err/2;

#ifdef DEBUG
	std::cout << " Error = " << Error << std::endl;
#endif

	// Take the output of the previous layer
	//    output_[layers_ - 2][k];

	BackPropagation_(v_delta, layers_ - 1);

      } // end if v_out.size() == v_control.size()
      ++Control;
    } // end current Era

    //   if ( Error > MIN_ERROR && max_era_ < MAX_ERA ) {
    //     Learn( V_IN, V_CONTROL, ETA, MIN_ERROR, MAX_ERA );
    //   }

    // Fill TH1F with the error, as a function of the era
    // Use SetBinContent, the histogram is created with bins = MAX_ERA
    if ( ERRORHISTO != 0 ) {
      ERRORHISTO->SetBinContent( max_era_+1, Error );
    }

    // End loop with the error condition
    if ( Error < MIN_ERROR ) break;

  } // end loop on the eras
  std::cout << "finished after " << max_era_ << " Eras" << std::endl;
  std::cout << "with error = " << Error << std::endl;

  // Write the weights to file
  // -------------------------

  // Iterate over the neurons
  for( unsigned int layer = 0; layer < layers_; ++layer ) {
    vector<Neuron>::iterator n_it = Layers_[layer].begin();
    for ( ; n_it != Layers_[layer].end(); ++n_it ) {
      // Iterate on the weights and modify them
      unsigned int weight_count = 0;
      vector<double>::iterator w_it = n_it->Weights().begin();
      for ( ; w_it != n_it->Weights().end(); ++w_it ) {
        //        cout << "weigth = " << *w_it << endl;
      }
    }
  }

  return( make_pair( max_era_, Error ) );
};

void NN::BackPropagation_( vector<double> & V_DELTA, unsigned int LAYER ) {

#ifdef DEBUG
  unsigned int count = 0;
  for ( vector<double>::iterator v_d_it = V_DELTA.begin(); v_d_it != V_DELTA.end(); ++v_d_it ) {
    std::cout << "V_DELTA["<< count <<"] = " << *v_d_it << std::endl;
    ++count;
  }
#endif

  // Take the output from the previous layer
  vector<double> * v_out_prev = &(output_[LAYER - 1]);
  vector<double> * v_out_this = &(output_[LAYER]);

  vector<Neuron> * v_n_ptr = &(Layers_[LAYER]);

  vector<double> temp_v_delta;

  // If it is not the last layer
  if ( LAYER > 0 ) {
    // First evaluate the new deltas for the previous layer
    // (must do this before the weights are modified)
    // ----------------------------------------------------

    // Iterate over the neurons of the previous layer
    unsigned int prev_neuron_size = Layers_[LAYER - 1].size();
    unsigned int prev_neuron_count = 0;
    for ( ; prev_neuron_count < prev_neuron_size; ++prev_neuron_count ) {

      double fprime = FPrime_((*v_out_prev)[prev_neuron_count]);

#ifdef DEBUG
      std::cout << "fprime("<<(*v_out_prev)[prev_neuron_count]<<"[prev_neuron_count = " << prev_neuron_count << "]) = " << fprime << std::endl;
#endif

      double deltak = 0.;
      unsigned int delta_count = 0;
      vector<double>::iterator d_it = V_DELTA.begin();
      for ( ; d_it != V_DELTA.end(); ++d_it ) {

	// Evaluate the new deltas for the previous layer
	deltak += (*v_n_ptr)[delta_count].Weights()[prev_neuron_count] * (*d_it);
      }
      // Store the deltak in temp_v_delta
      temp_v_delta.push_back( deltak*fprime );
    }
  }

  // Modify the weights
  // ------------------

  // Iterate over the neurons of the current layer
  vector<Neuron>::iterator n_it = Layers_[LAYER].begin();
  unsigned int neuron_count = 0;
  for ( ; n_it != Layers_[LAYER].end(); ++n_it ) {

    // Iterate on the weights and modify them
    // (to iterate on the weights has the same numbers than to
    // iterate on the neurons of the previous layer
    unsigned int weight_count = 0;
    vector<double>::iterator w_it = n_it->Weights().begin();

    for ( ; w_it != n_it->Weights().end(); ++w_it ) {

      // Modify the weight with the back-propagated part
      if ( LAYER > 0 ) {
#ifdef DEBUG
        cout << "v_momentum["<<LAYER<<"]["<<neuron_count<<"]["<<weight_count<<"] = " << v_momentum_[LAYER][neuron_count][weight_count] << endl;
#endif
	*w_it = *w_it -eta_*V_DELTA[neuron_count]*(*v_out_prev)[weight_count] + beta_*v_momentum_[LAYER][neuron_count][weight_count];
        v_momentum_[LAYER][neuron_count][weight_count] = ( -eta_*V_DELTA[neuron_count]*(*v_out_prev)[weight_count] );
        //        v_momentum_[LAYER][neuron_count][weight_count] = -eta_*V_DELTA[neuron_count]*(*v_out_prev)[weight_count] + beta_*v_momentum_[LAYER][neuron_count][weight_count];
#ifdef DEBUG
	std::cout << "weight[neuron_count = "<< neuron_count <<"][weight_count = " << weight_count << "] = " << *w_it << std::endl;
#endif
      }
      else {
	*w_it = *w_it -eta_*V_DELTA[neuron_count]*(v_in_)[weight_count] + beta_*v_momentum_[LAYER][neuron_count][weight_count];
        v_momentum_[LAYER][neuron_count][weight_count] = ( eta_*V_DELTA[neuron_count]*(v_in_)[weight_count] );
#ifdef DEBUG
	std::cout << "weight[neuron_count = "<< neuron_count <<"][weight_count = " << weight_count << "] = " << *w_it << std::endl;
#endif
      }
      ++weight_count;
    }
    ++neuron_count;
  }

  // Decrease the layer counter (back propagation)
  if( LAYER > 0 ) {
    BackPropagation_(temp_v_delta, LAYER - 1);
  }
};

#endif // NN_CC
