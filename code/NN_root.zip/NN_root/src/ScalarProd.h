#ifndef SCALARPROD_H
#define SCALARPROD_H

/////////////////////////////////////////////////////////////////////////////
//
// Sclar product template function object
// Author M. De Mattia - 17/8/2007
//
// Template class, the object containers passed must have a const_iterator.
// They must also be templates of <class, allocator>, where allocator is
// defined in the std header <memory>. This is true for the std container<T>
// classes.
// (Possible modification: template<class a, class b> where class a is the
// already defined container (for example pass vector<duoble> instead of
// vector) and class b is the type (in the same example it would be duoble)).
// The objects contained must have a product (*) operator defined and must
// be able to initialize = 0.
// If DEBUG is active the object container must also have the size() method
// since the size of the two containers is checked to be the same and if
// found different -1. is returned.
//
/////////////////////////////////////////////////////////////////////////////

#include <memory>

template <template <class a, class b> class c1, class c2> class ScalarProd {
 public:
  c2 operator() ( c1<c2, std::allocator<c2> > & v1, c1<c2, std::allocator<c2> > & v2 ) {
    typename c1<c2, std::allocator<c2> >::const_iterator v1_it = v1.begin();
    typename c1<c2, std::allocator<c2> >::const_iterator v2_it = v2.begin();

#ifdef DEBUG
    if ( v1.size() != v2.size() ) {
      return -1.;
    }
#endif

    c2 scalar_prod = 0.;

    for ( ; v1_it != v1.end(); ++v1_it ) {

      scalar_prod += (*v1_it) * (*v2_it);

      ++v2_it;
    }
    return scalar_prod;
  }
};

#endif
