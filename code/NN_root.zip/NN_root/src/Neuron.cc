#ifndef NEURON_CC
#define NEURON_CC

#include "Neuron.h"

using namespace std;

double Neuron::Transfer ( vector<double> & V_P ) {

  using namespace std;

  ScalarProd<vector, double> scalar;

  // P = V_P * weights_ (vector of inputs scalar vector of weights)

#ifdef DEBUG
  std::cout << "V_P.size() = " << V_P.size() << std::endl;
  std::cout << "weights_.size() = " << weights_.size() << std::endl;
#endif

  double P = scalar( V_P, weights_ );

#ifdef DEBUF
  std::cout << "P = " << P << std::endl;
#endif

  // Sigmoidal transfer function
  // F(P) = 1/(1+e^(-kP))

  return( 1./( 1. + exp(-k_*P) ) );
};

#endif // NEURON_CC
